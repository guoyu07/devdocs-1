<?php

namespace SwagExtendCustomProducts;

use Shopware\Components\Plugin;

class SwagExtendCustomProducts extends Plugin
{
}
